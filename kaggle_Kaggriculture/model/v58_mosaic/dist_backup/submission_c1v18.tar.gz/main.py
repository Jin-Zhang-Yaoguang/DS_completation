"""C1: 闭环启发式 agent,执行层为"每日路线规划器"。

我方农场在一天之内是确定性的(杂草与产出只在夜里结算,对手只影响市场),
所以每天把当天要做的事列成"访问点"(格 + 动作序列),用带容量的最廉价插入
排进各工人路线,出门前在仓库一次领足饲料/肥料/动物,傍晚回库交货。
战略层(日程/配额)与市场层沿用 C0。所有可调量在 P 中,可用 PARAMS_OVERRIDE 覆盖。
"""
import math

CROPS = {
    "WHEAT": dict(seed=10, first=2, maxday=4, interval=0, maxy=6, ongoing=False),
    "CARROT": dict(seed=20, first=2, maxday=3, interval=0, maxy=4, ongoing=False),
    "TOMATO": dict(seed=50, first=8, maxday=8, interval=1, maxy=4, ongoing=True),
    "STRAWBERRY": dict(seed=100, first=10, maxday=10, interval=2, maxy=4, ongoing=True),
    "MELON": dict(seed=80, first=10, maxday=12, interval=0, maxy=6, ongoing=False),
}
ANIMALS = {
    "GOOSE": dict(cost=300, struct="COOP", first=4, interval=1, held=4, product="EGG"),
    "COW": dict(cost=400, struct="PASTURE", first=8, interval=2, held=6, product="MILK"),
    "SHEEP": dict(cost=500, struct="PASTURE", first=6, interval=3, held=6, product="WOOL"),
}
PRODUCTS = ["WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL", "FERTILIZER"]
MOVES = {"NORTH": (0, -1), "SOUTH": (0, 1), "EAST": (1, 0), "WEST": (-1, 0)}
ACCESS = [(4, 4), (5, 4), (4, 5), (5, 5)]
LAND_PRICES = [1000, 2000, 4000]

P = {
    "hands": [5, 3, 4, 5, 4, 4, 7, 7, 8, 8, 11, 10, 9, 9, 9, 10] + [11] * 12 + [10, 10],
    "land_steps": [150, 265, 99999],
    "land_reserve": [0, 300, 1500],
    "struct_plan": [(0, 4, 0), (2, 5, 0), (3, 6, 0), (6, 8, 0), (7, 10, 0), (8, 12, 0), (9, 14, 0), (10, 16, 0), (11, 17, 0)],
    "animal_plan": [(0, 2, 2, 0), (2, 3, 2, 0), (3, 4, 2, 0), (6, 4, 4, 0), (7, 6, 4, 0), (8, 7, 6, 0), (9, 7, 8, 0), (10, 7, 10, 0), (11, 7, 12, 0)],
    "melon_cum": {0: 12},
    "straw_cum": {5: 4, 6: 12, 7: 16, 8: 20, 11: 33},
    "tomato_cum": {},
    "carrot_daily": {20: 3, 23: 5, 25: 6, 26: 3},
    "last_plant_day": {"WHEAT": 26, "CARROT": 26, "TOMATO": 19, "STRAWBERRY": 16, "MELON": 2},
    "plant_last_hour": 21,
    "fert_ages": {"STRAWBERRY": (9, 13), "TOMATO": (7, 10), "WHEAT": (2,), "CARROT": (2,)},
    "fert_start_day": 8,
    "fert_gain": {"WHEAT": 2, "CARROT": 1, "STRAWBERRY": 2, "TOMATO": 3},
    "exp_yield": {"WHEAT": 4, "CARROT": 3, "MELON": 6, "STRAWBERRY": 6, "TOMATO": 5},
    "beat_items": ("MILK", "WOOL", "STRAWBERRY"),
    "fert_hold_min_day": 8,
    "fert_keep": 15,
    "shed_guard": 85,
    "final_sell_step": 716,
    "feed_last_day": 28,
    "feed_stock_days": 1,
    "last_animal_day": 20,
    "hire_last_hour": 14,
    "hire_reserve_frac": 0.0,
    "replan_hours": (12,),
    "deposit_min_items": 1,
    "tw_optional_water": False,
    "day0_keep": 30,
    "dynamic_hire": True,
    "hire_first": True,
    "travel_per_visit": 0.8,
    "overhead_per_unit": 5.0,
    "max_hands": 13,
    "hands_floor": True,
    "adaptive_mix": True,
    "rush_items": (),
    "animal_prio": 0.5,
    "adaptive_crops": True,
    "econ_horizon_crop": 10,
    "crop_choices": ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY"),
    "straw_cap": 40,
    "tomato_cap": 24,
    "crop_life": {"WHEAT": 5, "CARROT": 4, "TOMATO": 11, "STRAWBERRY": 17, "MELON": 11},
    "crop_labor": {"WHEAT": 1.2, "CARROT": 1.25, "TOMATO": 1.0, "STRAWBERRY": 0.8, "MELON": 0.9},
    "labor_cost": 15.0,
    "crop_bias": {},
    "wheat_fallback": True,
    "straw_min_cum": {},
    "margin_w": 0.5,
    "filler": False,
    "follow": None,
    "deadline_crit": False,
    "seed_first": False,
    "sell_tol": 0.0,
    "urgency": True,
    "urgency_hire": False,
    "urg_animal_crit": 0.0,
    "feed_margin": 1.0,
    "hire_value_mult": 1.0,
    "sticky": True,
    "steal": True,
    "steal_min_gain": 1,
    "steal_feed": True,
    "idle_fill": False,
    "melon_near": False,
    "race_skip_water": False,
    "final_harvest_day": 29,
    "end_clean": True,
    "util_target": 0.0,
    "place_crit": 1.0,
    "feed_stock_early": 0,
    "zone_plan": False,
    "keep_cash": 0,
    "plan_no_deposit": True,
    "night_guard": True,
    "deposit_items": 5,
    "build_on_demand": True,
    "sell_front": 0,
    "fert_low_min": 0,
    "ongoing_water_crit": False,
    "night_guard_hour": 17,
    "night_margin": 3,
    "hands_cap": {},
    "feed_early_days": 2,
    "spread_place": True,
    "util_slack": 1,
    "steal_fert": False,
    "steal_head_gain": 0,
    "near_first": False,
    "mval_own_w": 0.0,
    "mval_deny_w": 0.0,
    "mval_horizon": 12,
    "sell_tol_items": ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL", "FERTILIZER"),
    "wheat_harvest_age": 3,
    "filler_buy": True,
    "filler_buy_max": 6,
    "adaptive_mix_from": 1,
    "book_until": 0,
    "book_wheat_cum": {0: 8, 2: 11, 3: 15, 4: 18},
    "book_straw_cum": {5: 4},
    "rush_value": 600,
    "rush_until_hour": 19,
    "rush_prio": 1.0,
    "wheat_floor_per_animal": 1.1,
    "wheat_keep_days": 3,
    "guard_wheat_days": 2.5,
    "econ_horizon": 8,
    "feed_cost_per_day": 40.0,
    "species_allowed": ("COW", "SHEEP", "GOOSE"),
    "species_bias": {"GOOSE": 1.5, "SHEEP": 1.3},
    "animal_roi": False,
    "animal_labor_cost": 10.0,
}
try:
    P.update(PARAMS_OVERRIDE)  # noqa: F821
except NameError:
    pass
for _k, _v in list(P.items()):
    if isinstance(_v, dict) and _v and all(isinstance(x, str) and x.lstrip("-").isdigit() for x in _v):
        P[_k] = {int(x): y for x, y in _v.items()}
    if isinstance(_v, list) and _v and all(isinstance(r, list) for r in _v):
        P[_k] = [tuple(r) for r in _v]

_ST = {}
_TEL = {}


# ============================================================================ 工具
def _g(d, k, default=None):
    if isinstance(d, dict):
        return d.get(k, default)
    try:
        return d[k]
    except Exception:
        return getattr(d, k, default)


def _dist(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def _shed_dist(p):
    return min(_dist(p, a) for a in ACCESS)


def _nearest_access(p):
    return min(ACCESS, key=lambda a: (_dist(p, a), ACCESS.index(a)))


def _step_toward(p, t):
    if p[1] != t[1]:
        return "SOUTH" if t[1] > p[1] else "NORTH"
    if p[0] != t[0]:
        return "EAST" if t[0] > p[0] else "WEST"
    return None


def _cum(table, day):
    v = 0
    for d in sorted(table):
        if d <= day:
            v = table[d]
    return v


def _plan_at(plan, day):
    cur = plan[0]
    for row in plan:
        if row[0] <= day:
            cur = row
    return cur


def _fib(n):
    a, b = 1, 1
    for _ in range(n):
        a, b = b, a + b
    return a


def _tel(k, n=1):
    _TEL[k] = _TEL.get(k, 0) + n


class View:
    def __init__(self, obs):
        self.me = int(_g(obs, "player", 0))
        self.day = int(_g(obs, "day", 0))
        self.hour = int(_g(obs, "hour", 0))
        st = _g(obs, "step", None)
        self.step = int(st) if st is not None else self.day * 24 + self.hour
        farms = _g(obs, "farms")
        self.farm = farms[self.me]
        self.opp = farms[1 - self.me] if len(farms) > 1 else None
        self.tiles = self.farm["tiles"]
        self.money = float(self.farm["money"])
        self.units = [tuple(self.farm["farmer"])] + [tuple(h) for h in self.farm["hands"]]
        priv = _g(obs, "private")
        self.shed = dict(_g(priv, "shed", {}) or {})
        self.seeds = dict(_g(priv, "seeds", {}) or {})
        invs = list(_g(priv, "inventories", []) or [])
        self.invs = [dict(invs[i]) if i < len(invs) and invs[i] else {} for i in range(len(self.units))]
        m = _g(obs, "market")
        self.prices = dict(m["prices"])
        self.minv = dict(m["inventory"])
        self.shops = list(_g(_g(obs, "town", {}), "unlocked_shops", []) or [])
        self.unlocked = list(self.farm["unlocked_quadrants"])
        self.hires_today = int(self.farm.get("hires_today", 0))

    def tile(self, x, y):
        return self.tiles[y][x]


def _new_state():
    return {"last_step": -1, "planted": {c: 0 for c in CROPS}, "struct_role": {}, "carrot_day": {},
            "routes": {}, "plan_key": None, "plan_units": 0}


# ============================================================================ L1 战略
def _shop_mods(v):
    s = v.shops
    return dict(
        berry=sum(x in ("BRUNCH_SPOT", "ICE_CREAM_SHOP", "SMOOTHIE_SHOP", "FARMERS_MARKET") for x in s),
        yarn=s.count("YARN_STORE"), pet=s.count("PET_CAFE"), pizza=s.count("PIZZA_SHOP"),
        fm=s.count("FARMERS_MARKET"), egg=sum(x in ("BAKERY", "BRUNCH_SPOT") for x in s),
        milk=sum(x in ("PIZZA_SHOP", "ICE_CREAM_SHOP", "SMOOTHIE_SHOP") for x in s), bakery=s.count("BAKERY"))


def _structure_layout(v, st):
    day = v.day
    _, npast, ncoop = _plan_at(P["struct_plan"], day)
    mods = _shop_mods(v)
    npast += min(mods["milk"], 2) if day >= 9 else 0
    if P["adaptive_mix"] and st.get("animal_tgt"):
        tg = st["animal_tgt"]
        npast = tg["COW"] + tg["SHEEP"]; ncoop = tg["GOOSE"]
    roles = st["struct_role"]
    for y in range(10):
        for x in range(10):
            t = v.tile(x, y)
            if isinstance(t, dict) and t.get("kind") in ("PASTURE", "COOP"):
                roles[(x, y)] = t["kind"]
    have_p = sum(1 for r in roles.values() if r == "PASTURE")
    have_c = sum(1 for r in roles.values() if r == "COOP")
    need = [("PASTURE", npast - have_p), ("COOP", ncoop - have_c)]
    cand = []
    for y in range(10):
        for x in range(10):
            if (x, y) in roles:
                continue
            t = v.tile(x, y)
            if t == "LOCKED":
                continue
            if t is None or (isinstance(t, dict) and t.get("kind") == "WEED"):
                cand.append((_shed_dist((x, y)), y, x))
    cand.sort()
    i = 0
    for kind, n in need:
        for _ in range(max(0, n)):
            if i >= len(cand):
                break
            _, y, x = cand[i]; i += 1
            roles[(x, y)] = kind


def _animal_targets(v, st=None, have=None):
    if P["follow"]:
        a = _follow_at(min(29, v.day + 1))["animals"]
        return {k: int(a.get(k, 0)) for k in ("COW", "SHEEP", "GOOSE")}
    _, cow, sheep, goose = _plan_at(P["animal_plan"], v.day)
    if not P["adaptive_mix"] or have is None or v.day < P["adaptive_mix_from"]:
        mods = _shop_mods(v)
        if v.day >= 9:
            cow += min(mods["milk"], 2)
        return {"COW": cow, "SHEEP": sheep, "GOOSE": goose}
    total = cow + sheep + goose
    return _animal_mix(v, st, total, have)


def _crop_econ(v, st, planned):
    """按边际收益为一个空作物格选作物(甜瓜仍按开局配额)。"""
    day = v.day
    last = P["last_plant_day"]
    pl = st["planted"]
    if day <= last["MELON"] and pl["MELON"] + planned["MELON"] < _cum(P["melon_cum"], day):
        return "MELON"
    if day <= last["STRAWBERRY"] and pl["STRAWBERRY"] + planned["STRAWBERRY"] < _cum(P["straw_min_cum"], day):
        return "STRAWBERRY"
    cache = st.setdefault("econ_cache", {})
    key = (v.step,)
    if cache.get("key") != key:
        horizon = max(4, min(P["econ_horizon_crop"], 29 - day))
        cache.update(key=key, horizon=horizon, dem=_demand(v, horizon), mine=_supply(v, v.farm),
                     opp=_supply(v, v.opp) if v.opp else {p: 0.0 for p in PRODUCTS})
    horizon, dem, mine, opp = cache["horizon"], cache["dem"], dict(cache["mine"]), cache["opp"]
    for c, n in planned.items():
        mine[c] += n * CROP_RATE.get(c, 0.5)
    feed_need = st.get("n_animals", 0)
    if day <= last["WHEAT"] and P["wheat_floor_per_animal"] > 0:
        target_animals = st.get("animal_total_target", feed_need)
        floor = math.ceil(max(feed_need, target_animals) * P["wheat_floor_per_animal"])
        if st.get("wheat_tiles", 0) + planned["WHEAT"] < floor:
            return "WHEAT"
    best = None
    for c in P["crop_choices"]:
        if day > last.get(c, 29):
            continue
        if c == "STRAWBERRY" and pl["STRAWBERRY"] + planned["STRAWBERRY"] >= P["straw_cap"]:
            continue
        if c == "TOMATO" and pl["TOMATO"] + planned["TOMATO"] >= P["tomato_cap"]:
            continue
        r = CROP_RATE[c]
        inv0 = v.minv.get(c, 10000)
        net = mine[c] + opp[c] - dem[c]
        p0 = _avg_price(c, inv0, net, horizon); p1 = _avg_price(c, inv0, net + r, horizon)
        mr = (mine[c] + r) * p1 - mine[c] * p0 + P["margin_w"] * opp[c] * (p0 - p1)
        if c == "WHEAT" and mine["WHEAT"] < feed_need:
            mr = max(mr, r * (v.prices.get("WHEAT", 30) + 2))
        mr -= CROPS[c]["seed"] / P["crop_life"][c] + P["labor_cost"] * P["crop_labor"][c]
        mr *= P["crop_bias"].get(c, 1.0)
        if best is None or mr > best[0]:
            best = (mr, c)
    if best and best[0] < 0 and P["wheat_fallback"] and day <= last["WHEAT"]:
        return "WHEAT"
    return best[1] if best else None


def _follow_at(day):
    F = P["follow"]
    ks = [d for d in F if d <= day]
    return F[max(ks)] if ks else F[min(F)]


def _follow_crop(v, st, planned):
    """分解实验:按目标格位构成选作物(缺口最大者),无缺口则留空。"""
    tg = _follow_at(v.day)["crops"]
    cache = st.setdefault("occ_cache", {})
    if cache.get("step") != v.step:
        occ = {c: 0 for c in CROPS}
        for y in range(10):
            for x in range(10):
                t = v.tile(x, y)
                if isinstance(t, dict) and t.get("kind") == "PLANT":
                    cd = CROPS[t["crop"]]
                    age = v.day - int(t["planted_day"])
                    if not cd["ongoing"] and (int(t.get("yield_units", 0)) >= cd["maxy"] or age >= cd["maxday"]):
                        continue
                    occ[t["crop"]] += 1
        cache.update(step=v.step, occ=occ)
    occ = cache["occ"]
    best = None
    for c in CROPS:
        d = tg.get(c, 0) - occ[c] - planned.get(c, 0)
        if d > 0 and (best is None or d > best[0]):
            best = (d, c)
    return best[1] if best else None


def _choose_crop(v, st, planned):
    if P["follow"]:
        return _follow_crop(v, st, planned)
    day = v.day
    if day < P["book_until"]:
        pl = st["planted"]
        if day <= P["last_plant_day"]["MELON"] and pl["MELON"] + planned["MELON"] < _cum(P["melon_cum"], day):
            return "MELON"
        if pl["STRAWBERRY"] + planned["STRAWBERRY"] < _cum(P["book_straw_cum"], day):
            return "STRAWBERRY"
        if pl["WHEAT"] + planned["WHEAT"] < _cum(P["book_wheat_cum"], day):
            return "WHEAT"
        return None
    if P["adaptive_crops"]:
        return _crop_econ(v, st, planned)
    day = v.day
    last = P["last_plant_day"]
    mods = _shop_mods(v)
    pl = st["planted"]
    if day <= last["MELON"] and pl["MELON"] + planned["MELON"] < _cum(P["melon_cum"], day):
        return "MELON"
    straw_target = _cum(P["straw_cum"], day) + (4 if (mods["berry"] >= 2 and day >= 6) else 0)
    if day <= last["STRAWBERRY"] and pl["STRAWBERRY"] + planned["STRAWBERRY"] < straw_target:
        return "STRAWBERRY"
    if (mods["pizza"] or mods["fm"]) and day <= last["TOMATO"] and pl["TOMATO"] + planned["TOMATO"] < _cum(P["tomato_cum"], day):
        return "TOMATO"
    if day <= last["CARROT"]:
        daily = _cum(P["carrot_daily"], day) * (1 + 1.5 * min(mods["pet"], 2) + 0.5 * mods["fm"])
        if st["carrot_day"].get(day, 0) + planned["CARROT"] < daily:
            return "CARROT"
    if day <= last["WHEAT"]:
        return "WHEAT"
    return None



# ============================================================================ 市场感知经济模块
MARKET_PARAMS = {
    "WHEAT": (25, 400, "sqrt", 0.80, "log", 0.20), "CARROT": (35, 450, "hinge", 1.00, "sqrt", 0.70),
    "TOMATO": (60, 200, "hinge", 0.40, "sqrt", 0.60), "STRAWBERRY": (120, 100, "sqrt", 0.70, "linear", 1.60),
    "MELON": (250, 300, "log", 0.20, "sq", 3.60), "EGG": (50, 332, "hinge", 0.40, "log", 0.20),
    "MILK": (160, 122, "sqrt", 0.60, "linear", 1.60), "WOOL": (200, 105, "log", 0.20, "sq", 3.20),
    "FERTILIZER": (100, 200, "linear", 0.40, "linear", 0.40),
}
SHOPS = {
    "BAKERY": ["EGG", "WHEAT"], "PIZZA_SHOP": ["MILK", "TOMATO", "WHEAT"], "BRUNCH_SPOT": ["EGG", "WHEAT", "STRAWBERRY"],
    "YARN_STORE": ["WOOL"], "ICE_CREAM_SHOP": ["STRAWBERRY", "MILK", "WHEAT"], "PET_CAFE": ["CARROT"],
    "SMOOTHIE_SHOP": ["STRAWBERRY", "MILK"], "FARMERS_MARKET": ["WHEAT", "CARROT", "TOMATO", "STRAWBERRY"],
}
# 满照料日产率(每头/每格/天)
RATE = {"COW": ("MILK", 1.5), "SHEEP": ("WOOL", 1.33), "GOOSE": ("EGG", 2.0)}
CROP_RATE = {"STRAWBERRY": 0.47, "WHEAT": 0.9, "CARROT": 0.85, "TOMATO": 0.6, "MELON": 0.55}


def _shape(f, x, T):
    x = max(0.0, x)
    if f == "linear":
        return x
    if f == "sq":
        return x * x
    if f == "sqrt":
        return math.sqrt(x)
    if f == "log":
        return math.log(1.0 + x)
    if f == "hinge":
        u = x / T
        return u + 8.0 * max(0.0, u - 1.0) ** 2
    return x


def _price(item, inv):
    base, T, bf, bt, af, at = MARKET_PARAMS[item]
    if inv < 10000:
        p = base + bt * base / _shape(bf, T, T) * _shape(bf, 10000 - inv, T)
    else:
        p = base - at * base / _shape(af, T, T) * _shape(af, inv - 10000, T)
    return max(1, int(round(p)))


def _demand(v, horizon):
    """每日平均需求(件/天):已解锁商店 + 镇中心 + 未来解锁商店的期望。"""
    d = {p: (1.0 if p != "FERTILIZER" else 0.0) for p in PRODUCTS}
    for s in v.shops:
        prods = SHOPS.get(s, [])
        for p in prods:
            d[p] += 6.0 * (2 if len(prods) == 1 else 1)
    exp = {p: 0.0 for p in PRODUCTS}
    for s, prods in SHOPS.items():
        for p in prods:
            exp[p] += 6.0 * (2 if len(prods) == 1 else 1) / 8.0
    future = [u for u in range(3, 25, 3) if u > v.day][: max(0, 8 - len(v.shops))]
    for u in future:
        frac = max(0.0, (v.day + horizon - u)) / horizon
        for p in PRODUCTS:
            d[p] += exp[p] * min(1.0, frac)
    return d


def _supply(v, farm):
    s = {p: 0.0 for p in PRODUCTS}
    for row in farm["tiles"]:
        for t in row:
            if isinstance(t, dict):
                if "animal" in t:
                    prod, r = RATE[t["animal"]]
                    s[prod] += r
                    s["FERTILIZER"] += 0.9
                elif t.get("kind") == "PLANT":
                    s[t["crop"]] += CROP_RATE.get(t["crop"], 0.5)
    return s


def _avg_price(item, inv0, net_per_day, days):
    inv = inv0; tot = 0.0
    for _ in range(max(1, days)):
        inv += net_per_day
        tot += _price(item, inv)
    return tot / max(1, days)


def _animal_mix(v, st, total, have):
    """按我方边际收益逐头分配畜种。have: 现有(含仓库/在途)各种数量。"""
    horizon = max(4, min(P["econ_horizon"], 29 - v.day))
    dem = _demand(v, horizon)
    mine = _supply(v, v.farm)
    opp = _supply(v, v.opp) if v.opp else {p: 0.0 for p in PRODUCTS}
    counts = dict(have)
    # 现有在场动物已计入 mine;仓库/在途的补上
    onfarm = {a: 0 for a in ANIMALS}
    for row in v.tiles:
        for t in row:
            if isinstance(t, dict) and "animal" in t:
                onfarm[t["animal"]] += 1
    for a in ANIMALS:
        extra = counts[a] - onfarm[a]
        if extra > 0:
            prod, r = RATE[a]; mine[prod] += extra * r
    allowed = [a for a in ANIMALS if a in P["species_allowed"]]
    n = sum(counts.values())
    fert_net = mine["FERTILIZER"] + opp["FERTILIZER"] - dem["FERTILIZER"]
    while n < total:
        best = None
        for a in allowed:
            prod, r = RATE[a]
            inv0 = v.minv.get(prod, 10000)
            base_net = mine[prod] + opp[prod] - dem[prod]
            p0 = _avg_price(prod, inv0, base_net, horizon)
            p1 = _avg_price(prod, inv0, base_net + r, horizon)
            mr = (mine[prod] + r) * p1 - mine[prod] * p0 + P["margin_w"] * opp[prod] * (p0 - p1)
            if P["animal_roi"]:
                days_left = max(0, 29 - v.day)
                prod_days = max(0, days_left - ANIMALS[a]["first"])
                fert_v = _avg_price("FERTILIZER", v.minv.get("FERTILIZER", 10000), fert_net, horizon) * 0.8
                daily = fert_v - (v.prices.get("WHEAT", 30) + 2) - P["animal_labor_cost"]
                total = prod_days * mr + days_left * daily - ANIMALS[a]["cost"]
                score = total / ANIMALS[a]["cost"] * P["species_bias"].get(a, 1.0)
            else:
                score = (mr - P["feed_cost_per_day"]) * P["species_bias"].get(a, 1.0)
            if best is None or score > best[0]:
                best = (score, a)
        a = best[1]
        counts[a] += 1; n += 1
        prod, r = RATE[a]; mine[prod] += r; fert_net += 0.9
    return counts


# ============================================================================ 访问点生成
def _fert_worth(v, crop):
    gain = P["fert_gain"].get(crop, 0) * max(1, v.prices.get(crop, 1))
    return gain > max(1, v.prices.get("FERTILIZER", 50)) * 1.1


def _tdv(v, crop):
    """一格一天的产值(用于衡量推迟一天种植/收获的损失)。"""
    return P["exp_yield"][crop] * _mval(v, crop) / P["crop_life"][crop]


def _mval(v, item):
    """对局价值:当前价 − 我方后续销量×单件压价 + 对手后续销量×单件压价(按步缓存)。"""
    price = max(1, v.prices.get(item, 1))
    if P["mval_own_w"] == 0 and P["mval_deny_w"] == 0:
        return price
    c = _ST.setdefault("_mval", {})
    if c.get("step") != (v.me, v.step):
        c.clear(); c["step"] = (v.me, v.step)
        c["mine"] = _supply(v, v.farm)
        c["opp"] = _supply(v, v.opp) if v.opp else {p: 0.0 for p in PRODUCTS}
    if item not in c:
        inv = int(v.minv.get(item, 10000))
        dp = max(0, _price(item, inv) - _price(item, inv + 1))
        days = max(0, min(P["mval_horizon"], 29 - v.day))
        c[item] = price - P["mval_own_w"] * c["mine"].get(item, 0) * days * dp + P["mval_deny_w"] * c["opp"].get(item, 0) * days * dp
    return max(1.0, c[item])


def _urgency(v, t, ops, crop_planted):
    """今天不做这个访问点会永久损失多少钱。返回 (损失, 是否必做, 过滤后的动作)。"""
    day = v.day
    u = 0.0; crit = 0
    ops2 = list(ops)
    names = [o[0] for o in ops]
    if t is None or (isinstance(t, dict) and t.get("kind") == "WEED"):
        if "BUILD_PASTURE" in names or "BUILD_COOP" in names:
            u += 120.0
        if "PLACE" in names:
            u += 150.0; crit = max(crit, P["place_crit"])  # 已买到的动物:每晚放一步都损失产出
        if crop_planted:
            u += _tdv(v, crop_planted)
        return u + 2.0, crit, ops2
    k = t.get("kind")
    if k == "PLANT":
        crop = t["crop"]; cd = CROPS[crop]; price = _mval(v, crop)
        age = day - int(t["planted_day"]); yu = int(t.get("yield_units", 0))
        cons = int(t.get("consecutive_unwatered", 0)); fa = int(t.get("fertilized_until_day", -1)) >= day
        if "FERTILIZE" in names:
            u += P["fert_gain"].get(crop, 0) * price - 0.5 * max(1, v.prices.get("FERTILIZER", 50)); fa = True
        if "WATER" in names:
            if cons >= 1:
                u += cd["seed"] + yu * price + 3 * _tdv(v, crop); crit = 1
            if not cd["ongoing"]:
                ws = (cd["maxday"] + 1) // 2
                if ws <= age <= cd["maxday"] and yu < cd["maxy"]:
                    u += price * (2 if fa else 1)
            else:
                dsf = day + 1 - int(t["planted_day"]) - cd["first"]
                if dsf >= 0 and dsf % cd["interval"] == 0 and fa:
                    u += price
                    if P["ongoing_water_crit"]:
                        crit = max(crit, 1)  # 施肥期间的产出日:不浇水则加成作废
        if "HARVEST" in names:
            if not cd["ongoing"]:
                if age >= cd["maxday"]:
                    u += yu * price; crit = 1
                else:
                    u += _tdv(v, crop)
            else:
                mls = int(t.get("max_lifespan_step", -1))
                if mls > 0 and v.step >= mls - 24:
                    u += yu * price; crit = 1
                elif yu >= cd["maxy"] - 1:
                    u += price
                else:
                    u += 3.0
        if crop_planted:
            u += _tdv(v, crop_planted)
    elif k in ("PASTURE", "COOP") and "animal" in t:
        a = t["animal"]; ad = ANIMALS[a]; pp = _mval(v, ad["product"]); wp = max(1, v.prices.get("WHEAT", 30))
        unfed = int(t.get("consecutive_unfed", 0))
        dsf = day + 1 - int(t.get("placed_day", day)) - ad["first"]
        prod_night = dsf >= 0 and dsf % ad["interval"] == 0
        pending = int(t.get("pending_care_bonus", 0))
        if "FEED" in names:
            loss = pp * ((pending if prod_night else 0) + 1)
            if unfed >= 1:
                u += ad["cost"] + loss; crit = 1
            elif loss > wp * P["feed_margin"]:
                u += loss - wp
                crit = max(crit, P["urg_animal_crit"] if a != "GOOSE" else 0)
            else:
                ops2 = [o for o in ops2 if o[0] not in ("FEED", "CARE")]
                _tel("feed_skipped")
        elif "CARE" in names and t.get("fed_today"):
            u += pp
        if "COLLECT_FERTILIZER" in names:
            u += max(5.0, 0.8 * v.prices.get("FERTILIZER", 30))
        if "HARVEST" in names:
            held = int(t.get("yield_units", 0))
            u += pp if (prod_night and held + 2 > ad["held"]) else 3.0
    elif k in ("PASTURE", "COOP"):
        if "PLACE" in names:
            u += 150.0; crit = max(crit, P["place_crit"])
    return u, crit, ops2


def _build_visits(v, st, seed_budget, animals_avail):
    """返回访问点列表:dict(xy, ops=[(op,arg)], val, crit, wheat, fert_use, fert_get, animal, plants={crop:n})。"""
    day, hour = v.day, v.hour
    visits = []
    fert_use_total = [0]
    planned = {c: 0 for c in CROPS}
    seeds = dict(seed_budget)
    roles = st["struct_role"]
    can_plant = hour <= P["plant_last_hour"]
    avail = dict(animals_avail)

    def plant_ops(xy):
        if not can_plant:
            return [], 0.0, None
        crop = _choose_crop(v, st, planned)
        if crop is None or seeds.get(crop, 0) <= 0:
            return [], 0.0, None
        seeds[crop] -= 1; planned[crop] += 1
        val = P["exp_yield"][crop] * max(1, v.prices.get(crop, 1)) - CROPS[crop]["seed"]
        return [("PLANT", crop), ("WATER", None)], max(20.0, 0.5 * val), crop

    cells = [(x, y) for y in range(10) for x in range(10)]
    if P["near_first"]:
        cells.sort(key=lambda c: (_shed_dist(c), c[1], c[0]))  # 近仓库的格子先决定作物
    elif P["melon_near"] and day <= P["last_plant_day"]["MELON"]:
        # 只把甜瓜配额放到离仓库最近的空地(抢先收获、抢先卖),其余格子保持原顺序
        quota = max(0, _cum(P["melon_cum"], day) - st["planted"]["MELON"])
        free = [c for c in cells if v.tile(*c) is None and c not in roles]
        near = sorted(free, key=lambda c: (_shed_dist(c), c[1], c[0]))[:quota]
        cells = near + [c for c in cells if c not in near]
    for x, y in cells:
        if True:
            t = v.tile(x, y)
            if t == "LOCKED":
                continue
            xy = (x, y)
            ops, val, crit = [], 0.0, 0
            wheat = fert_use = fert_get = 0
            animal = None
            crop_planted = None
            role = roles.get(xy)
            if t is None:
                if role:
                    a = next((b for b in ANIMALS if ANIMALS[b]["struct"] == role and avail.get(b, 0) > 0), None)
                    if a or not P["build_on_demand"]:
                        ops = [("BUILD_" + role, None)]; val = 150.0  # build_on_demand:有动物可放才建棚,避免空棚占地
                    if a:
                        ops.append(("PLACE", a)); avail[a] -= 1; animal = a; val += 300.0
                else:
                    ops, val, crop_planted = plant_ops(xy)
            elif isinstance(t, dict):
                k = t.get("kind")
                if k == "WEED":
                    ops = [("DIG", None)]; val = 10.0
                    if role:
                        ops.append(("BUILD_" + role, None)); val += 150.0
                    else:
                        po, pv, crop_planted = plant_ops(xy)
                        ops += po; val += pv
                elif k == "PLANT":
                    crop = t["crop"]; cd = CROPS[crop]
                    age = day - int(t["planted_day"])
                    yu = int(t.get("yield_units", 0))
                    watered = bool(t.get("watered_today"))
                    cons = int(t.get("consecutive_unwatered", 0))
                    fa = int(t.get("fertilized_until_day", -1)) >= day
                    price = max(1, v.prices.get(crop, 1))
                    fert_stock = int(v.shed.get("FERTILIZER", 0)) + sum(inv.get("FERTILIZER", 0) for inv in v.invs)
                    low_ok = cd["ongoing"] or P["fert_low_min"] <= 0 or fert_stock - fert_use_total[0] > P["fert_low_min"]  # 短周期作物只用富余肥料,草莓优先
                    if low_ok and day >= P["fert_start_day"] and not fa and age in P["fert_ages"].get(crop, ()) and (cd["ongoing"] or not watered) and _fert_worth(v, crop):
                        fert_use_total[0] += 1
                        ops.append(("FERTILIZE", None)); fa = True; fert_use += 1
                        val += P["fert_gain"][crop] * price
                    need_w = False
                    if not watered:
                        if cons >= 1:
                            need_w = True; crit = 1; val += cd["seed"] + price * 3
                        if not cd["ongoing"]:
                            ws = (cd["maxday"] + 1) // 2
                            if ws <= age <= cd["maxday"] and yu < cd["maxy"]:
                                need_w = True; val += price * (2 if fa else 1)
                                yu = min(cd["maxy"], yu + (2 if fa else 1))
                        else:
                            dsf = day + 1 - int(t["planted_day"]) - cd["first"]
                            if dsf >= 0 and dsf % cd["interval"] == 0 and fa:
                                need_w = True; val += price
                        if not need_w and P["tw_optional_water"]:
                            need_w = True
                    if need_w:
                        ops.append(("WATER", None))
                    if yu > 0 and age >= cd["first"]:
                        if cd["ongoing"]:
                            ops.append(("HARVEST", None)); val += yu * price
                        elif yu >= cd["maxy"] or age >= cd["maxday"] or (crop == "WHEAT" and 0 < P["wheat_harvest_age"] <= age and (watered or need_w)) or day >= P["final_harvest_day"]:
                            ops.append(("HARVEST", None)); val += yu * price
                            if age > cd["maxday"] or (P["deadline_crit"] and age >= cd["maxday"]):
                                crit = 1
                            if not role:
                                po, pv, crop_planted = plant_ops(xy)
                                ops += po; val += pv
                elif k in ("PASTURE", "COOP"):
                    if "animal" in t:
                        a = t["animal"]; ad = ANIMALS[a]
                        pp = max(1, v.prices.get(ad["product"], 1))
                        if not t.get("fed_today") and day <= P["feed_last_day"]:
                            ops.append(("FEED", None)); wheat += 1; val += pp * 1.2
                            if int(t.get("consecutive_unfed", 0)) >= 1:
                                crit = 1; val += ad["cost"]
                        if not t.get("cared_today") and day <= P["feed_last_day"]:
                            ops.append(("CARE", None)); val += pp * 0.9
                        if t.get("fertilizer_available"):
                            ops.append(("COLLECT_FERTILIZER", None)); fert_get += 1
                            val += max(5, v.prices.get("FERTILIZER", 30) * 0.8)
                        if int(t.get("yield_units", 0)) > 0:
                            ops.append(("HARVEST", None)); val += int(t["yield_units"]) * pp
                        if ops and (not t.get("fed_today") or not t.get("cared_today")):
                            crit = max(crit, P["animal_prio"])
                    else:
                        a = next((b for b in ANIMALS if ANIMALS[b]["struct"] == k and avail.get(b, 0) > 0), None)
                        if a:
                            ops = [("PLACE", a)]; avail[a] -= 1; animal = a; val = 300.0
            rush = bool(isinstance(t, dict) and t.get("kind") == "PLANT" and t.get("crop") in P["rush_items"] and any(o[0] == "HARVEST" for o in ops))
            if rush:
                crit = max(crit, P["rush_prio"])
            core_len = len(ops)
            if isinstance(t, dict) and t.get("kind") in ("PLANT", "WEED") and crop_planted:
                pi = next((j for j, o in enumerate(ops) if o[0] == "PLANT"), None)
                if pi is not None and pi > 0:
                    core_len = pi
            if ops and P["urgency"]:
                val, crit, ops = _urgency(v, t, ops, crop_planted)
                if rush:
                    crit = max(crit, P["rush_prio"])
                    if P["sticky"] and crop_planted and core_len < len(ops):
                        ops = ops[:core_len]; crop_planted = None  # 急卖:只收不补种,收完立刻回库
                    if P["race_skip_water"]:
                        ops = [o for o in ops if o[0] != "WATER"] or ops  # 抢收:不等浇水加产,直接收
                wheat = sum(1 for o in ops if o[0] == "FEED")
                core_len = min(core_len, len(ops))
            hv = 0
            if ops and isinstance(t, dict):
                if any(o[0] == "HARVEST" for o in ops):
                    hv += max(1, int(t.get("yield_units", 0)))
                hv += sum(1 for o in ops if o[0] == "COLLECT_FERTILIZER")
            if ops:
                visits.append(dict(xy=xy, ops=ops, core_len=core_len, val=val, crit=crit, wheat=wheat, fert_use=fert_use, rush=rush, hv=hv,
                                   fert_get=fert_get, animal=animal, crop=crop_planted,
                                   prod=any(o[0] in ("HARVEST", "COLLECT_FERTILIZER") for o in ops)))
    return visits, planned


# ============================================================================ 路线规划(带容量的最廉价插入)
_DAY = {"d": 0}


def v_day_ok():
    return _DAY["d"] < 29


def _route_cost(start, seq, visits, carried, stock):
    """返回 (总步数, 取货列表)。取货在出发前于仓库完成。"""
    pos = start
    need_w = sum(visits[k]["wheat"] for k in seq)
    # 肥料:按顺序模拟余额
    bal = carried.get("FERTILIZER", 0); deficit = 0
    for k in seq:
        vs = visits[k]
        # 同一访问点内先收后用(收肥在动物格,施肥在作物格,不会同格)
        bal += vs["fert_get"]
        bal -= vs["fert_use"]
        deficit = max(deficit, -bal)
    animals = {}
    for k in seq:
        a = visits[k]["animal"]
        if a:
            animals[a] = animals.get(a, 0) + 1
    picks = []
    w = max(0, need_w - carried.get("WHEAT", 0))
    if w > 0:
        picks.append(("WHEAT", w))
    if deficit > 0:
        picks.append(("FERTILIZER", deficit))
    for a, n in animals.items():
        n2 = n - carried.get(a, 0)
        if n2 > 0:
            picks.append((a, n2))
    t = 0
    if picks:
        if pos not in ACCESS:
            acc = _nearest_access(pos); t += _dist(pos, acc); pos = acc
        t += len(picks)
    prod = False
    for k in seq:
        vs = visits[k]
        t += _dist(pos, vs["xy"]) + len(vs["ops"]); pos = vs["xy"]
        prod = prod or vs["prod"]
    items = sum(visits[k].get("hv", 0) for k in seq)
    if prod and not (P["plan_no_deposit"] and v_day_ok() and (P["deposit_items"] <= 0 or items <= P["deposit_items"])):
        t += _shed_dist(pos) + 1  # 夜里货物自动入库:规划不必为收尾回仓预留步数(最后一天除外)
    return t, picks


def _plan(v, st, visits):
    hour = v.hour
    cap = 24 - hour
    n = len(v.units)
    starts = list(v.units)
    carried = [dict(inv) for inv in v.invs]
    routes = [[] for _ in range(n)]
    costs = [0] * n
    stock = dict(v.shed)
    wheat_left = int(stock.get("WHEAT", 0)) + sum(c.get("WHEAT", 0) for c in carried)
    fert_left = int(stock.get("FERTILIZER", 0)) + sum(c.get("FERTILIZER", 0) for c in carried) + sum(vs["fert_get"] for vs in visits)
    if P["urgency"]:
        order = sorted(range(len(visits)), key=lambda k: (-visits[k]["crit"], -visits[k]["val"] / (len(visits[k]["ops"]) + P["travel_per_visit"])))
    else:
        order = sorted(range(len(visits)), key=lambda k: (-visits[k]["crit"], -visits[k]["val"] / (len(visits[k]["ops"]) + 1.0)))
    seeded = set()
    if P["sticky"] and st.get("routes"):
        # 粘性重排:保留每个工人尚未完成的访问点(按原顺序),只插入新出现的访问点
        where = {tuple(vs["xy"]): k for k, vs in enumerate(visits)}
        for i, r in st["routes"].items():
            if not isinstance(i, int) or i >= n:
                continue
            for vv in r.get("visits", []):
                k = where.get(tuple(vv["xy"]))
                if k is None or k in seeded:
                    continue
                vs = visits[k]
                if vs["wheat"] > wheat_left or vs["fert_use"] > fert_left:
                    continue
                cand = routes[i] + [k]
                c, _ = _route_cost(starts[i], cand, visits, carried[i], stock)
                if c > cap:
                    continue
                routes[i] = cand; costs[i] = c; seeded.add(k)
                wheat_left -= vs["wheat"]; fert_left -= vs["fert_use"]
        _tel("sticky_kept", len(seeded))
    if P["zone_plan"] and not seeded and n >= 2:
        # 区域分配:按优先级筛出当天可做的访问点,蛇形排序后按工作量切成连续段,每个工人扫一段
        pri = {k: r_ for r_, k in enumerate(order)}
        take = []; wl, fl = wheat_left, fert_left
        for k in order:
            vs = visits[k]
            if vs["wheat"] > wl:
                vs["ops"] = [o for o in vs["ops"] if o[0] != "FEED"]; vs["wheat"] = 0
            if vs["fert_use"] > fl:
                vs["ops"] = [o for o in vs["ops"] if o[0] != "FERTILIZE"]; vs["fert_use"] = 0
            if not vs["ops"]:
                continue
            wl -= vs["wheat"]; fl -= vs["fert_use"]; take.append(k)
        take.sort(key=lambda k: (visits[k]["xy"][1], visits[k]["xy"][0] if visits[k]["xy"][1] % 2 == 0 else 9 - visits[k]["xy"][0]))
        w = []; prev = None
        for k in take:
            xy = visits[k]["xy"]
            w.append(len(visits[k]["ops"]) + (_dist(prev, xy) if prev else 2)); prev = xy
        total = sum(w); per = total / n
        segs = [[] for _ in range(n)]; acc = 0.0; si = 0
        for k, wk in zip(take, w):
            if acc >= per * (si + 1) and si < n - 1:
                si += 1
            segs[si].append(k); acc += wk
        for i in range(n):
            seq = segs[i]
            while seq:
                c, _ = _route_cost(starts[i], seq, visits, carried[i], stock)
                if c <= cap:
                    break
                drop = max((q for q in seq if not visits[q]["crit"]), key=lambda q: pri[q], default=None)
                if drop is None:
                    drop = max(seq, key=lambda q: pri[q])
                seq = [q for q in seq if q != drop]
            routes[i] = seq
            costs[i] = _route_cost(starts[i], seq, visits, carried[i], stock)[0] if seq else 0
            for q in seq:
                seeded.add(q); wheat_left -= visits[q]["wheat"]; fert_left -= visits[q]["fert_use"]
        _tel("zone_seeded", len(seeded))
    for k in order:
        if k in seeded:
            continue
        vs = visits[k]
        if vs["wheat"] > wheat_left:
            _tel("feed_stripped_d%02d" % v.day)
            # 没有饲料:去掉喂食动作
            vs["ops"] = [o for o in vs["ops"] if o[0] != "FEED"]; vs["wheat"] = 0
            if not vs["ops"]:
                continue
        if vs["fert_use"] > fert_left:
            vs["ops"] = [o for o in vs["ops"] if o[0] != "FERTILIZE"]; vs["fert_use"] = 0
            if not vs["ops"]:
                continue
        best = None
        allowed = range(n)
        if P["sticky"] and (vs.get("rush") or (P["spread_place"] and vs.get("animal"))):
            key_ = "rush" if vs.get("rush") else "animal"
            nr = [sum(1 for q in routes[i] if visits[q].get(key_)) for i in range(n)]
            allowed = [i for i in range(n) if nr[i] == min(nr)]
        for i in allowed:
            seq = routes[i]
            for pos_k in range(len(seq) + 1):
                cand = seq[:pos_k] + [k] + seq[pos_k:]
                c, _ = _route_cost(starts[i], cand, visits, carried[i], stock)
                if c > cap:
                    continue
                delta = c - costs[i]
                if best is None or delta < best[0]:
                    best = (delta, i, cand, c)
        if not best and vs.get("core_len", len(vs["ops"])) < len(vs["ops"]):
            # 放不下完整访问点:只做必做部分(收获),放弃补种
            if vs.get("crop"):
                planned_drop = vs["crop"]
                _tel("replant_dropped")
            vs["ops"] = vs["ops"][:vs["core_len"]]; vs["crop"] = None
            for i in range(n):
                seq = routes[i]
                for pos_k in range(len(seq) + 1):
                    cand = seq[:pos_k] + [k] + seq[pos_k:]
                    c, _ = _route_cost(starts[i], cand, visits, carried[i], stock)
                    if c > cap:
                        continue
                    delta = c - costs[i]
                    if best is None or delta < best[0]:
                        best = (delta, i, cand, c)
        if not best:
            _tel("unfit_%s" % vs["ops"][0][0])
        if best:
            _, i, cand, c = best
            routes[i] = cand; costs[i] = c
            wheat_left -= vs["wheat"]; fert_left -= vs["fert_use"]
    # 2-opt 改进路程
    for i in range(n):
        seq = routes[i]
        improved = True
        while improved and len(seq) >= 3:
            improved = False
            for a in range(len(seq) - 1):
                for b in range(a + 1, len(seq)):
                    cand = seq[:a] + seq[a:b + 1][::-1] + seq[b + 1:]
                    c, _ = _route_cost(starts[i], cand, visits, carried[i], stock)
                    if c < costs[i]:
                        seq = cand; costs[i] = c; improved = True
            routes[i] = seq
    if P["rush_items"]:
        for i in range(n):
            seq = routes[i]
            rush = [k for k in seq if visits[k].get("rush")]
            if rush:
                rest = [k for k in seq if not visits[k].get("rush")]
                cand = rush + rest
                c, _ = _route_cost(starts[i], cand, visits, carried[i], stock)
                if c <= cap:
                    routes[i] = cand; costs[i] = c
    plan = {}
    for i in range(n):
        c, picks = _route_cost(starts[i], routes[i], visits, carried[i], stock)
        plan[i] = {"picks": list(picks), "visits": [dict(xy=visits[k]["xy"], ops=list(visits[k]["ops"]), rush=visits[k].get("rush")) for k in routes[i]],
                   "deposit": any(visits[k]["prod"] for k in routes[i])}
    _tel("plans")
    _tel("planned_visits", sum(len(r) for r in routes))
    _tel("unplanned_visits", len(visits) - sum(len(r) for r in routes))
    return plan


# ============================================================================ 执行
def _op_valid(v, invs, i, xy, op, arg, seeds_left, plant_count):
    t = v.tile(*xy)
    inv = invs[i]
    if op == "WATER":
        return isinstance(t, dict) and t.get("kind") == "PLANT" and not t.get("watered_today")
    if op == "HARVEST":
        return isinstance(t, dict) and int(t.get("yield_units", 0)) > 0 and (t.get("kind") != "PLANT" or v.day - int(t.get("planted_day", 0)) >= CROPS[t["crop"]]["first"])
    if op == "PLANT":
        return t is None and seeds_left.get(arg, 0) - plant_count.get(arg, 0) > 0
    if op == "FERTILIZE":
        return isinstance(t, dict) and t.get("kind") == "PLANT" and inv.get("FERTILIZER", 0) > 0
    if op == "FEED":
        return isinstance(t, dict) and "animal" in t and not t.get("fed_today") and inv.get("WHEAT", 0) > 0
    if op == "CARE":
        return isinstance(t, dict) and "animal" in t and not t.get("cared_today")
    if op == "COLLECT_FERTILIZER":
        return isinstance(t, dict) and "animal" in t and t.get("fertilizer_available")
    if op == "DIG":
        return isinstance(t, dict) and "animal" not in t
    if op in ("BUILD_PASTURE", "BUILD_COOP"):
        return t is None
    if op == "PLACE":
        return isinstance(t, dict) and t.get("kind") == ANIMALS[arg]["struct"] and "animal" not in t and inv.get(arg, 0) > 0
    return False


def _simulate_op(v, invs, i, xy, op, arg):
    """同一步内后续校验要看到本步变化:这里只更新随身物品与临时地块标记。"""
    inv = invs[i]
    if op == "FEED":
        inv["WHEAT"] -= 1
    elif op == "FERTILIZE":
        inv["FERTILIZER"] -= 1
    elif op == "PLACE":
        inv[arg] -= 1
    elif op == "COLLECT_FERTILIZER":
        inv["FERTILIZER"] = inv.get("FERTILIZER", 0) + 1


def _filler(v, st, pos, r, claimed, reserved, seeds_left, plant_count):
    """空闲工人补位:就近空地/杂草补种(作物由经济模块选,缺种子时换有种子的作物)。"""
    hour = v.hour
    if not (1 <= hour <= P["plant_last_hour"]):
        return False
    planned = dict(st.get("planned_today") or {c: 0 for c in CROPS})
    for c, n in st.get("filler_planned", {}).items():
        planned[c] = planned.get(c, 0) + n
    crop = _choose_crop(v, st, planned)
    if crop is None:
        return False
    avail = {c: seeds_left.get(c, 0) - plant_count.get(c, 0) - reserved.get(c, 0) for c in CROPS}
    roles = st["struct_role"]
    tiles = []
    for y in range(10):
        for x in range(10):
            xy = (x, y)
            if xy in claimed or xy in roles:
                continue
            t = v.tile(x, y)
            if t is None:
                ops = []
            elif isinstance(t, dict) and t.get("kind") == "WEED":
                ops = [("DIG", None)]
            else:
                continue
            d = _dist(pos, xy)
            if hour + d + len(ops) + 2 > 23:
                continue
            tiles.append((d, y, x, ops))
    if not tiles:
        return False
    if avail.get(crop, 0) <= 0:
        want = st.setdefault("filler_want", {})
        want[crop] = want.get(crop, 0) + 1
        alt = [c for c in ("WHEAT", "CARROT", "STRAWBERRY", "TOMATO") if avail.get(c, 0) > 0 and v.day <= P["last_plant_day"].get(c, 29)]
        if not alt:
            return False
        crop = alt[0]
    tiles.sort()
    d, y, x, ops = tiles[0]
    claimed.add((x, y)); reserved[crop] = reserved.get(crop, 0) + 1
    fp = st.setdefault("filler_planned", {}); fp[crop] = fp.get(crop, 0) + 1
    r["visits"].append(dict(xy=(x, y), ops=ops + [("PLANT", crop), ("WATER", None)], rush=False))
    _tel("filler")
    return True


_STEALABLE = {"WATER", "HARVEST", "PLANT", "DIG", "CARE", "COLLECT_FERTILIZER", "BUILD_PASTURE", "BUILD_COOP", "WATER_NEW"}


def _steal(v, st, i, pos, r):
    """工作窃取:空闲工人从别人队列(非当前目标)里接手自己能更早赶到的访问点。"""
    plan = st["routes"]
    best = None
    for j, rj in plan.items():
        if j == i or not isinstance(j, int) or j >= len(v.units):
            continue
        vis = rj.get("visits", [])
        if len(vis) < 2:
            continue
        # 估计原主人到达每个访问点的时间
        p = v.units[j]; eta = 0
        if rj.get("picks"):
            acc = _nearest_access(p); eta += _dist(p, acc) + len(rj["picks"]); p = acc
        for q, vv in enumerate(vis):
            eta += _dist(p, vv["xy"]); p = vv["xy"]
            feed_ok = P["steal_feed"] and all(o[0] in _STEALABLE or o[0] == "FEED" for o in vv["ops"]) and int(v.shed.get("WHEAT", 0)) > 0
            fert_ok = P["steal_fert"] and all(o[0] in _STEALABLE or o[0] == "FERTILIZE" for o in vv["ops"]) and int(v.shed.get("FERTILIZER", 0)) > 0
            head_ok = q >= 1 or (P["steal_head_gain"] > 0 and _dist(v.units[j], vv["xy"]) >= P["steal_head_gain"] + 1)
            if head_ok and (all(o[0] in _STEALABLE for o in vv["ops"]) or feed_ok or fert_ok):
                need_pick = any(o[0] in ("FEED", "FERTILIZE") for o in vv["ops"])
                if need_pick:
                    acc = _nearest_access(pos)
                    mine = _dist(pos, acc) + 1 + _dist(acc, vv["xy"])
                else:
                    mine = _dist(pos, vv["xy"])
                gain = eta - mine
                mg = P["steal_min_gain"] if q >= 1 else P["steal_head_gain"]
                if gain >= mg and v.hour + mine + len(vv["ops"]) <= 23 and (best is None or gain > best[0]):
                    best = (gain, j, q)
            eta += len(vv["ops"])
    if not best:
        return False
    _, j, q = best
    vv = plan[j]["visits"].pop(q)
    nf = sum(1 for o in vv["ops"] if o[0] == "FEED")
    if nf:
        r["picks"].append(("WHEAT", nf))
    nz = sum(1 for o in vv["ops"] if o[0] == "FERTILIZE")
    if nz:
        r["picks"].append(("FERTILIZER", nz))
    r["visits"].append(vv)
    if any(o[0] in ("HARVEST", "COLLECT_FERTILIZER") for o in vv["ops"]):
        r["deposit"] = True
    _tel("steals")
    return True


def _idle_fill(v, st, seed_budget, animals_avail, idle):
    """把当前没人负责的访问点按损失密度插给空闲工人(只动空闲工人的路线)。"""
    routes = st["routes"]
    busy = {tuple(vv["xy"]) for r in routes.values() for vv in r.get("visits", [])}
    visits, _ = _build_visits(v, st, seed_budget, animals_avail)
    free = [vs for vs in visits if tuple(vs["xy"]) not in busy and all(o[0] in _STEALABLE for o in vs["ops"])]
    if not free:
        return
    free.sort(key=lambda x: (-x["crit"], -x["val"] / (len(x["ops"]) + P["travel_per_visit"])))
    cap = 24 - v.hour
    for i in idle:
        if i >= len(v.units):
            continue
        pos = v.units[i]; seq = []
        for vs in list(free):
            cand = seq + [vs]
            t = 0; p = pos
            for x in cand:
                t += _dist(p, x["xy"]) + len(x["ops"]); p = x["xy"]
            if any(x["prod"] for x in cand) and not (P["plan_no_deposit"] and v_day_ok()):
                t += _shed_dist(p) + 1
            if t <= cap:
                seq = cand; free.remove(vs)
            if len(seq) >= 4:
                break
        if seq:
            routes[i] = {"picks": [], "visits": [dict(xy=x["xy"], ops=list(x["ops"]), rush=x.get("rush")) for x in seq],
                         "deposit": any(x["prod"] for x in seq)}
            _tel("idle_fills", len(seq))


def _execute(v, st, invs, shed):
    plan = st["routes"]
    acts = []
    picks = {}
    drops = {}
    seeds_left = {c: int(v.seeds.get(c, 0)) for c in CROPS}
    plant_count = {}
    claimed = set(); reserved = {}
    if P["filler"]:
        st["filler_want"] = {}
        for r_ in plan.values():
            for vv in r_.get("visits", []):
                claimed.add(tuple(vv["xy"]))
                for op, arg in vv["ops"]:
                    if op == "PLANT":
                        reserved[arg] = reserved.get(arg, 0) + 1
    for i, pos in enumerate(v.units):
        r = plan.get(i)
        if r is None and P["steal"] and v.hour >= 1:
            r = plan[i] = {"picks": [], "visits": [], "deposit": False}
        if r is None and P["filler"] and v.hour >= 1:
            r = plan[i] = {"picks": [], "visits": [], "deposit": False}
        a = None
        guard = 0
        while r is not None and a is None and guard < 12:
            guard += 1
            if r["picks"]:
                if pos in ACCESS:
                    it, n = r["picks"][0]
                    n = min(n, int(shed.get(it, 0)))
                    r["picks"].pop(0)
                    if n > 0:
                        a = ["PICKUP", it, n]; shed[it] -= n; picks[it] = picks.get(it, 0) + n
                        invs[i][it] = invs[i].get(it, 0) + n
                    else:
                        _tel("pick_short")
                    continue
                a = [_step_toward(pos, _nearest_access(pos))]
                break
            rush_val = sum(q * v.prices.get(k, 1) for k, q in invs[i].items() if k in P["rush_items"] and q > 0)
            more_rush = any(vv.get("rush") for vv in r["visits"])
            if rush_val >= P["rush_value"] and v.hour < P["rush_until_hour"] and not more_rush:
                if pos in ACCESS:
                    k_ = max((q * v.prices.get(k, 1), k) for k, q in invs[i].items() if k in P["rush_items"] and q > 0)[1]
                    q_ = invs[i][k_]
                    a = ["PLACE", k_, q_]; drops[k_] = drops.get(k_, 0) + q_; invs[i][k_] = 0
                    _tel("rush_drop")
                    break
                a = [_step_toward(pos, _nearest_access(pos))]
                break
            if r["visits"]:
                vis = r["visits"][0]
                if pos != vis["xy"]:
                    a = [_step_toward(pos, vis["xy"])]
                    break
                while vis["ops"]:
                    op, arg = vis["ops"].pop(0)
                    if _op_valid(v, invs, i, vis["xy"], op, arg, seeds_left, plant_count):
                        if op == "PLANT":
                            plant_count[arg] = plant_count.get(arg, 0) + 1
                            st["planted"][arg] += 1
                            if arg == "CARROT":
                                st["carrot_day"][v.day] = st["carrot_day"].get(v.day, 0) + 1
                            a = ["PLANT", arg]
                            # 种下后当步不能再看到新作物,下一步浇水时校验会通过
                            if vis["ops"] and vis["ops"][0][0] == "WATER":
                                vis["ops"][0] = ("WATER_NEW", None)
                        elif op == "PLACE":
                            a = ["PLACE", arg]
                        else:
                            a = [op]
                        _simulate_op(v, invs, i, vis["xy"], op, arg)
                        break
                    elif op == "WATER_NEW":
                        a = ["WATER"]; break
                    else:
                        _tel("skip_" + op)
                if not vis["ops"]:
                    r["visits"].pop(0)
                if a is None:
                    continue
                break
            if r.get("deposit"):
                has = any(q > 0 and k in PRODUCTS for k, q in invs[i].items())
                if not has:
                    r["deposit"] = False; continue
                if pos in ACCESS:
                    keep = [k for k, q in invs[i].items() if q > 0 and k in ("WHEAT",) + tuple(ANIMALS)]
                    if keep:
                        cand = [(q * v.prices.get(k, 1), k, q) for k, q in invs[i].items() if q > 0 and k in PRODUCTS and k not in keep]
                        if cand:
                            _, k, q = max(cand)
                            a = ["PLACE", k, q]; drops[k] = drops.get(k, 0) + q; invs[i][k] = 0
                        else:
                            r["deposit"] = False; continue
                    else:
                        a = ["DROP"]
                        for k, q in invs[i].items():
                            if q > 0:
                                drops[k] = drops.get(k, 0) + q
                        invs[i] = {}
                        r["deposit"] = False
                    break
                a = [_step_toward(pos, _nearest_access(pos))]
                break
            if P["filler"] and _filler(v, st, pos, r, claimed, reserved, seeds_left, plant_count):
                continue
            if P["steal"] and v.hour >= 1 and _steal(v, st, i, pos, r):
                continue
            break
        if P["end_clean"] and v.step >= 720 - 1 - _shed_dist(pos) - 1 and any(q > 0 and k_ in PRODUCTS for k_, q in invs[i].items()):
            # 最后几步:带着产品的工人直奔仓库卸货,让终局卖单能卖掉
            if pos in ACCESS:
                a = ["DROP"]
                for k_, q in invs[i].items():
                    if q > 0:
                        drops[k_] = drops.get(k_, 0) + q
                invs[i] = {}
            else:
                a = [_step_toward(pos, _nearest_access(pos))]
        if a is None or a[0] is None:
            a = ["PASS"]
        if a[0] in MOVES:
            _tel("move")
        elif a[0] == "PASS":
            _tel("pass")
        else:
            _tel("work")
        if a[0] != "PASS":
            st["busy_" + str(v.day)] = st.get("busy_" + str(v.day), 0) + 1
        acts.append(a)
    return acts, picks, drops


# ============================================================================ 主决策
def _decide(v, st):
    day, hour = v.day, v.hour
    _DAY["d"] = day
    _structure_layout(v, st)
    invs = [dict(x) for x in v.invs]
    shed = dict(v.shed)

    n_animals = 0
    for y in range(10):
        for x in range(10):
            t = v.tile(x, y)
            if isinstance(t, dict) and "animal" in t:
                n_animals += 1

    st["n_animals"] = n_animals
    st["wheat_tiles"] = sum(1 for y in range(10) for x in range(10) if isinstance(v.tile(x, y), dict) and v.tile(x, y).get("crop") == "WHEAT")
    _, c_, s_, g_ = _plan_at(P["animal_plan"], day)
    st["animal_total_target"] = c_ + s_ + g_
    # 种子预算:现有种子 + 本步可买(按预估现金)
    est_cash = v.money + _est_sales(v, n_animals)
    keep_cash = P["keep_cash"]
    seed_budget = {c: int(v.seeds.get(c, 0)) + int(max(0.0, est_cash - keep_cash) // CROPS[c]["seed"]) for c in CROPS}
    animals_avail = {a: int(v.shed.get(a, 0)) + sum(inv.get(a, 0) for inv in invs) for a in ANIMALS}

    key = (day, len(v.units))
    need_plan = (st["plan_key"] != key) or (hour in P["replan_hours"] and st.get("plan_hour") != hour)
    if not need_plan and hour <= 20:
        # 新到动物且有空结构时重排
        empty_struct = any(isinstance(v.tile(x, y), dict) and v.tile(x, y).get("kind") in ("PASTURE", "COOP") and "animal" not in v.tile(x, y)
                           for y in range(10) for x in range(10))
        if empty_struct and any(v.shed.get(a, 0) > 0 for a in ANIMALS) and st.get("plan_hour") != hour:
            need_plan = True
    planned = st.get("planned_today", {c: 0 for c in CROPS})
    if hour == 0:
        st["filler_planned"] = {}
        # 只有农夫在:领当天饲料后原地等,市场雇工
        st["routes"] = {}
        st["plan_key"] = None
        w = min(max(0, n_animals - invs[0].get("WHEAT", 0)), int(shed.get("WHEAT", 0)), 8)
        if P["end_clean"] and day > P["feed_last_day"]:
            w = 0  # 停喂之后不再领饲料(否则终局烂在手里)
        acts = [["PICKUP", "WHEAT", w]] if (w > 0 and v.units[0] in ACCESS) else [["PASS"]]
        picks = {"WHEAT": w} if w > 0 and acts[0][0] == "PICKUP" else {}
        drops = {}
        if picks:
            invs[0]["WHEAT"] = invs[0].get("WHEAT", 0) + w
        # 预估今天种植以便买种子;按工作量定人手
        vis0, planned = _build_visits(v, st, seed_budget, animals_avail)
        st["planned_today"] = planned
        ops = sum(len(x["ops"]) for x in vis0)
        need = ops + P["travel_per_visit"] * len(vis0)
        units = max(1, math.ceil(need / (23.0 - P["overhead_per_unit"])))
        st["hands_target"] = min(P["max_hands"], max(P["hands"][min(day, len(P["hands"]) - 1)] if P["hands_floor"] else 0, units - 1))
        if P["hands_cap"]:
            st["hands_target"] = min(st["hands_target"], _cum(P["hands_cap"], day) or 99)
        if P["util_target"] > 0 and day >= 2 and st.get("busy_" + str(day - 1)):
            # 利用率反馈:昨天实际忙碌步数 / (23 × 目标利用率) = 今天需要的人数
            need_u = math.ceil(st["busy_" + str(day - 1)] / (23.0 * P["util_target"]))
            st["hands_target"] = max(0, min(st["hands_target"], need_u - 1 + P["util_slack"]))
        if P["urgency"] and P["urgency_hire"]:
            capu = 23.0 - P["overhead_per_unit"]
            costf = lambda x: len(x["ops"]) + P["travel_per_visit"]
            crit_cost = sum(costf(x) for x in vis0 if x["crit"])
            rest = sorted((x for x in vis0 if not x["crit"]), key=lambda x: -x["val"] / costf(x))
            n_units = max(1, math.ceil(crit_cost / capu))
            left = n_units * capu - crit_cost
            i = 0
            while i < len(rest) and left >= costf(rest[i]):
                left -= costf(rest[i]); i += 1
            while n_units - 1 < P["max_hands"] and i < len(rest):
                chunk_v = 0.0; room = capu + left; j = i
                while j < len(rest) and room >= costf(rest[j]):
                    room -= costf(rest[j]); chunk_v += rest[j]["val"]; j += 1
                if chunk_v <= _fib(n_units - 1) * P["hire_value_mult"]:
                    break
                n_units += 1; i = j; left = room
            st["hands_target"] = min(P["max_hands"], n_units - 1)
        _tel("hands_target_sum", st["hands_target"])
    else:
        if need_plan:
            visits, planned = _build_visits(v, st, seed_budget, animals_avail)
            st["routes"] = _plan(v, st, visits)
            st["plan_key"] = key; st["plan_hour"] = hour
            st["planned_today"] = planned
        elif P["idle_fill"] and st.get("idle_units") and hour <= 22:
            _idle_fill(v, st, seed_budget, animals_avail, st["idle_units"])
        acts, picks, drops = _execute(v, st, invs, shed)
        st["idle_units"] = [i for i, a in enumerate(acts) if a and a[0] == "PASS"]

    proj = dict(v.shed)
    for k, n in picks.items():
        proj[k] = proj.get(k, 0) - n
    for k, n in drops.items():
        proj[k] = proj.get(k, 0) + n
    carried_animals = sum(inv.get(a, 0) for inv in v.invs for a in ANIMALS) + sum(int(v.shed.get(a, 0)) for a in ANIMALS)
    market = _market(v, st, proj, n_animals + carried_animals, planned)
    return {"farmer": acts[0], "hands": acts[1:], "market": market}


def _est_sales(v, n_animals):
    tot = 0.0
    for item in PRODUCTS:
        have = int(v.shed.get(item, 0))
        if item == "WHEAT":
            have -= n_animals * 3
        if have > 0:
            tot += have * v.prices.get(item, 1) * 0.8
    return tot


# ============================================================================ L3 市场
def _market(v, st, proj, n_animals, planned_today):
    day, hour, step = v.day, v.hour, v.step
    orders = []
    cash = v.money

    sells = []
    for item in PRODUCTS:
        have = int(proj.get(item, 0))
        if have <= 0:
            continue
        keep = 0
        if item == "WHEAT":
            keep = int(math.ceil(n_animals * (P["wheat_keep_days"]) + 2)) if day < P["feed_last_day"] else 0
        elif item == "FERTILIZER":
            if day >= P["fert_hold_min_day"] and step < P["final_sell_step"]:
                keep = P["fert_keep"]
        q = have - keep
        if q <= 0:
            continue
        if item in P["beat_items"] and step < P["final_sell_step"] and hour < 22:
            crowded = sum(proj.values()) >= P["shed_guard"]
            if step % 4 != 1 and not crowded:
                continue
        price = v.prices.get(item, 1)
        if price <= 1 and step < P["final_sell_step"]:
            continue
        if P["sell_tol"] > 0 and item in P["sell_tol_items"] and step < P["final_sell_step"] and sum(proj.values()) < P["shed_guard"]:
            # 分批卖:只卖到价格跌幅不超过 sell_tol 为止
            inv0 = int(v.minv.get(item, 10000)); floor_p = price * (1.0 - P["sell_tol"])
            k = 0
            while k < q and _price(item, inv0 + k + 1) >= floor_p:
                k += 1
            q = max(1, k)
        sells.append((price, item, q))
    sold = {it: q for _, it, q in sells}
    after = {k: int(proj.get(k, 0)) - sold.get(k, 0) for k in proj}
    incoming = sum(sum(n for k, n in inv.items() if k in PRODUCTS) for inv in v.invs) if hour >= 18 else 0
    over = sum(max(0, n) for n in after.values()) + incoming - P["shed_guard"]
    night = P["night_guard"] and hour >= P["night_guard_hour"]
    if night:
        # 夜间守卫:夜里工人身上的货自动入库,超过仓库上限 100 的部分被丢弃;把身上已带的 + 路线里剩余收获都算进来
        exp = sum(sum(n for k, n in inv.items() if k in PRODUCTS) for inv in v.invs)
        for r_ in (st.get("routes") or {}).values():
            for vv in r_.get("visits", []):
                t_ = v.tile(*vv["xy"])
                if isinstance(t_, dict):
                    if any(o[0] == "HARVEST" for o in vv["ops"]):
                        exp += int(t_.get("yield_units", 0)) + 2
                    if any(o[0] == "COLLECT_FERTILIZER" for o in vv["ops"]):
                        exp += 1
        over = max(over, sum(max(0, n) for n in after.values()) + exp - (100 - P["night_margin"]))
    if over > 0:
        floor = {"WHEAT": int(n_animals * P["guard_wheat_days"]), "FERTILIZER": P["fert_keep"] // 2 if day >= P["fert_hold_min_day"] else 0}
        if night:
            floor = {"WHEAT": n_animals + 2, "FERTILIZER": 2}
        for item in sorted(PRODUCTS, key=lambda it: (it not in ("FERTILIZER",), v.prices.get(it, 1))):
            if over <= 0:
                break
            extra = min(over, max(0, after.get(item, 0) - floor.get(item, 0)))
            if extra > 0:
                sold[item] = sold.get(item, 0) + extra; over -= extra
        sells = [(v.prices.get(it, 1), it, q) for it, q in sold.items() if q > 0]
    sells.sort(reverse=True)
    target = st.get("hands_target", P["hands"][min(day, len(P["hands"]) - 1)]) if P["dynamic_hire"] else P["hands"][min(day, len(P["hands"]) - 1)]
    have = len(v.units) - 1
    ht = v.hires_today
    n_hire = 0
    if hour <= P["hire_last_hour"]:
        c0 = cash
        while have + n_hire < target and n_hire < 10:
            cost = _fib(ht + n_hire)
            if cost > c0 - 5:
                break
            c0 -= cost; n_hire += 1
    hires_first = n_hire > 0 and P["hire_first"]
    front = []
    if hires_first and P["sell_front"] > 0:
        # 挂单位置决定成交先后:最贵的几笔卖单排在雇工前面,抢在对手同类卖单之前成交
        front = sells[:max(0, min(P["sell_front"], 10 - n_hire - len(orders)))]  # 先保证雇工订单挂得上
        for price, item, q in front:
            orders.append(["SELL", item, int(q)]); cash += q * price * 0.9
        sells = sells[len(front):]
    if hires_first:
        for _ in range(n_hire):
            orders.append(["HIRE"]); cash -= _fib(ht + len([o for o in orders if o[0] == "HIRE"]) - 1)
    for price, item, q in sells:
        if len(orders) >= 10:
            break
        orders.append(["SELL", item, int(q)])
        cash += q * price * 0.9
    hires = n_hire if hires_first else 0
    while not hires_first and have + hires < target and hour <= P["hire_last_hour"] and len(orders) < 10:
        cost = _fib(ht + hires)
        if cost > cash - 5:
            break
        orders.append(["HIRE"]); cash -= cost; hires += 1

    wprice = max(1, v.prices.get("WHEAT", 30))
    have_w = proj.get("WHEAT", 0) + sum(inv.get("WHEAT", 0) for inv in v.invs)
    if day < P["feed_last_day"] and len(orders) < 10:
        fsd = P["feed_stock_early"] if (P["feed_stock_early"] and day <= P["feed_early_days"]) else P["feed_stock_days"]
        want = n_animals * fsd + 2
        if have_w < want:
            k = int(min(want - have_w, (cash - 2) // (wprice + 2)))
            if k > 0:
                orders.append(["BUY_PRODUCT", "WHEAT", k]); cash -= k * (wprice + 2); have_w += k
    nxt = P["hands"][min(day + 1, len(P["hands"]) - 1)]
    reserve = P["hire_reserve_frac"] * sum(_fib(i) for i in range(nxt)) * (1 if hour >= 12 else 0.5) + max(0, n_animals * 2 - have_w) * wprice
    spend = cash - reserve

    if P["seed_first"]:
        # 种子优先:当天计划种植缺的种子先买,再考虑买地/动物
        fw0 = st.get("filler_want", {}) if (P["filler"] and P["filler_buy"]) else {}
        for crop in ("MELON", "STRAWBERRY", "WHEAT", "CARROT", "TOMATO"):
            need = planned_today.get(crop, 0) - int(v.seeds.get(crop, 0))
            if fw0.get(crop):
                need = max(need, 0) + min(fw0[crop], P["filler_buy_max"])
            if need > 0 and len(orders) < 10:
                k = min(need, int(max(0.0, cash - 5) // CROPS[crop]["seed"]))
                if k > 0:
                    orders.append(["BUY_SEED", crop, k]); cash -= k * CROPS[crop]["seed"]; spend -= k * CROPS[crop]["seed"]
        planned_today = {}
    nq = len(v.unlocked)
    land_due = (_follow_at(min(29, day + 1))["nq"] > nq) if P["follow"] else (nq - 1 < len(LAND_PRICES) and step >= P["land_steps"][nq - 1])
    if nq - 1 < len(LAND_PRICES) and land_due and len(orders) < 10:
        price = LAND_PRICES[nq - 1]
        if spend >= price + P["land_reserve"][nq - 1]:
            orders.append(["BUY_LAND"]); cash -= price; spend -= price

    have_a = {a: 0 for a in ANIMALS}
    empty = {"PASTURE": 0, "COOP": 0}
    for y in range(10):
        for x in range(10):
            t = v.tile(x, y)
            if isinstance(t, dict) and "animal" in t:
                have_a[t["animal"]] += 1
            elif isinstance(t, dict) and t.get("kind") in empty:
                empty[t["kind"]] += 1
    for (xy, r) in st["struct_role"].items():
        if v.tile(*xy) is None:
            empty[r] += 1
    for a in ANIMALS:
        n_have = int(v.shed.get(a, 0)) + sum(inv.get(a, 0) for inv in v.invs)
        have_a[a] += n_have
        empty[ANIMALS[a]["struct"]] -= n_have
    tgt = _animal_targets(v, st, dict(have_a))
    st["animal_tgt"] = tgt
    if day <= P["last_animal_day"]:
        for a in ("COW", "SHEEP", "GOOSE"):
            s = ANIMALS[a]["struct"]
            n = min(tgt[a] - have_a[a], empty[s])
            while n > 0 and len(orders) < 10 and spend >= ANIMALS[a]["cost"] + wprice * 3:
                orders.append(["BUY_ANIMAL", a, 1]); cash -= ANIMALS[a]["cost"]; spend -= ANIMALS[a]["cost"]; n -= 1; empty[s] -= 1

    fw = st.get("filler_want", {}) if (P["filler"] and P["filler_buy"]) else {}
    for crop in ("MELON", "STRAWBERRY", "WHEAT", "CARROT", "TOMATO"):
        n = planned_today.get(crop, 0)
        need = n - int(v.seeds.get(crop, 0))
        if fw.get(crop):
            need = max(need, 0) + min(fw[crop], P["filler_buy_max"])
        if need > 0 and len(orders) < 10:
            k = min(need, int(max(0.0, spend) // CROPS[crop]["seed"]))
            if k > 0:
                orders.append(["BUY_SEED", crop, k]); cash -= k * CROPS[crop]["seed"]; spend -= k * CROPS[crop]["seed"]
    return orders[:10]


# ============================================================================ 入口
def _fallback(obs):
    try:
        farm = _g(obs, "farms")[int(_g(obs, "player", 0))]
        return {"farmer": ["PASS"], "hands": [["PASS"] for _ in farm["hands"]], "market": []}
    except Exception:
        return {"farmer": ["PASS"], "hands": [], "market": []}


def agent(observation, configuration=None):
    try:
        v = View(observation)
        st = _ST.get(v.me)
        if st is None or v.step == 0 or v.step <= st["last_step"]:
            st = _ST[v.me] = _new_state()
        st["last_step"] = v.step
        return _decide(v, st)
    except Exception:
        import traceback
        _ST.setdefault("errors", []).append(traceback.format_exc())
        return _fallback(observation)
